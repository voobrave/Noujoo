# M11 — CLI and benchmarks

The module CLI is available as `python -m harness.cli` (and as `app-builder` after editable installation).

```bash
python -m harness.cli doctor
python -m harness.cli new "Build a simple todo app"
python -m harness.cli runs
python -m harness.cli recover run_001
python -m harness.cli runtime --workspace ./my-project -- python -c "print('hello')"
python -m harness.cli test --workspace ./my-project
python -m harness.cli benchmark --workspace ./benchmark-work --iterations 5
```

Benchmark results are local, informational microbenchmarks, not claims about
production throughput. Runtime/test commands return non-zero exit status on
failure so scripts can check them.
