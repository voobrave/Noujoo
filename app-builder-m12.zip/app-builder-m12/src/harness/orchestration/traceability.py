from harness.verification.traceability import TraceabilityEngine
def traceability_stage(state, tasks, verification_results, workspace):
    engine = TraceabilityEngine()
    report = engine.build(state.run_id, state.spec, tasks, verification_results)
    engine.save(report, workspace / "traceability.json")
    state.review = report.model_dump(mode="json")
    state.checkpoints.append("003-traceability.json")
    return report
