"""M8 final requirement-review pipeline stage."""
from pathlib import Path
from harness.agents.reviewer import RequirementReviewer
from harness.models.traceability import TraceabilityReport
from harness.models.run import RunStatus


def requirement_review_stage(state, traceability, workspace: Path | str | None = None,
                              store=None):
    if state.spec is None:
        raise ValueError("Cannot review a run without a validated AppSpec")
    root = Path(workspace or state.workspace)
    reviewer = RequirementReviewer()
    report = reviewer.review(state.run_id, state.spec, traceability, root)
    reviewer.save(report, root / "review.json")
    state.review = report.model_dump(mode="json")
    state.status = RunStatus.REVIEW_DONE if report.status == "PASS" else RunStatus.FAIL
    if store is not None:
        store.checkpoint(state, "005-review.json", report.model_dump(mode="json"))
    else:
        state.checkpoints.append("005-review.json")
    return report
