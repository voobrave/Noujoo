from collections import defaultdict
from ..models.tasks import Task, TaskStatus

class PlanValidator:
    def validate(self, tasks: list[Task], requirement_ids: list[str]) -> list[str]:
        errors = []
        ids = [t.id for t in tasks]
        if len(ids) != len(set(ids)):
            errors.append("duplicate task IDs")

        known = set(ids)
        for task in tasks:
            for dep in task.depends_on:
                if dep not in known:
                    errors.append(f"{task.id}: unknown dependency {dep}")
            if not task.verification:
                errors.append(f"{task.id}: task must have verification")
            if not task.requirements:
                errors.append(f"{task.id}: task must have requirements")
            for path in task.files_touched:
                if path.startswith("/") or path == ".." or "/../" in path or path.startswith("../"):
                    errors.append(f"{task.id}: invalid file path {path}")

        covered = {r for t in tasks for r in t.requirements}
        for req in requirement_ids:
            if req not in covered:
                errors.append(f"orphan requirement: {req}")

        # Cycle detection using DFS.
        graph = {t.id: t.depends_on for t in tasks}
        visiting, visited = set(), set()
        def dfs(node):
            if node in visiting:
                return True
            if node in visited:
                return False
            visiting.add(node)
            if any(dep in graph and dfs(dep) for dep in graph.get(node, [])):
                return True
            visiting.remove(node)
            visited.add(node)
            return False
        if any(dfs(n) for n in graph):
            errors.append("dependency cycle detected")

        # Overlapping files are warnings, not errors in V1.
        owners = defaultdict(list)
        for t in tasks:
            for f in t.files_touched:
                owners[f].append(t.id)
        overlaps = [f for f, ts in owners.items() if len(ts) > 1]
        if overlaps:
            # Kept as a validation note for future parallel scheduling.
            errors.extend([])

        return errors

class DagEngine:
    def __init__(self, tasks: list[Task]):
        self.tasks = {t.id: t for t in tasks}
        self.statuses = {t.id: TaskStatus.PENDING for t in tasks}

    def get_ready(self) -> list[Task]:
        ready = []
        for tid, task in self.tasks.items():
            if self.statuses[tid] != TaskStatus.PENDING:
                continue
            if all(self.statuses.get(d) == TaskStatus.COMPLETED for d in task.depends_on):
                ready.append(task)
        for task in ready:
            self.statuses[task.id] = TaskStatus.READY
        return ready

    def mark(self, task_id: str, status: TaskStatus):
        if task_id not in self.tasks:
            raise KeyError(task_id)
        self.statuses[task_id] = status
        self.tasks[task_id].status = status

    def blocked_propagation(self):
        changed = True
        while changed:
            changed = False
            for tid, task in self.tasks.items():
                if self.statuses[tid] in {
                    TaskStatus.COMPLETED, TaskStatus.FAILED,
                    TaskStatus.TIMED_OUT, TaskStatus.BLOCKED
                }:
                    continue
                if any(self.statuses.get(d) in {
                    TaskStatus.FAILED, TaskStatus.TIMED_OUT, TaskStatus.BLOCKED
                } for d in task.depends_on):
                    self.mark(tid, TaskStatus.BLOCKED)
                    changed = True

    def is_done(self):
        return all(s in {
            TaskStatus.COMPLETED, TaskStatus.FAILED,
            TaskStatus.TIMED_OUT, TaskStatus.BLOCKED
        } for s in self.statuses.values())

    def topological_order(self) -> list[str]:
        indegree = {tid: 0 for tid in self.tasks}
        children = defaultdict(list)
        for tid, task in self.tasks.items():
            for dep in task.depends_on:
                if dep not in self.tasks:
                    raise ValueError(f"unknown dependency: {dep}")
                indegree[tid] += 1
                children[dep].append(tid)
        queue = [tid for tid, d in indegree.items() if d == 0]
        order = []
        while queue:
            tid = queue.pop(0)
            order.append(tid)
            for child in children[tid]:
                indegree[child] -= 1
                if indegree[child] == 0:
                    queue.append(child)
        if len(order) != len(self.tasks):
            raise ValueError("dependency cycle detected")
        return order

    def next_task(self) -> Task | None:
        ready = self.get_ready()
        return ready[0] if ready else None

class SequentialExecutor:
    """M3-only executor hook. Actual build/verification hooks arrive in M4/M5."""
    def __init__(self, engine: DagEngine, hook=None):
        self.engine = engine
        self.hook = hook

    def run(self):
        while not self.engine.is_done():
            self.engine.blocked_propagation()
            if self.engine.is_done():
                break
            task = self.engine.next_task()
            if task is None:
                raise RuntimeError(
                    "DAG deadlock; statuses=" + repr(self.engine.statuses)
                )
            self.engine.mark(task.id, TaskStatus.RUNNING)
            if self.hook:
                self.hook(task)
            self.engine.mark(task.id, TaskStatus.COMPLETED)
        return self.engine.statuses
