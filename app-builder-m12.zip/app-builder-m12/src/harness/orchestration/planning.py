from harness.models.run import RunStatus
from ..agents.planner import PlannerAgent
from .dag import PlanValidator

def plan_stage(store, run_id, llm):
    state = store.load(run_id)
    if state.spec is None:
        raise ValueError("spec must exist before planning")
    tasks = PlannerAgent(llm).plan(state.spec)
    errors = PlanValidator().validate(tasks, [r.id for r in state.spec.requirements])
    if errors:
        raise ValueError("Plan validation failed: " + "; ".join(errors))
    state.plan = tasks
    state.status = RunStatus.PLAN_DONE
    store.checkpoint(
        state, "002-plan.json",
        {"tasks": [t.model_dump(mode="json") for t in tasks]}
    )
    store.save(state)
    return tasks
