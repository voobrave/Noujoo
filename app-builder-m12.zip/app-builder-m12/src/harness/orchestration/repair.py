from __future__ import annotations
import hashlib
import re
from dataclasses import dataclass, field
from collections import Counter
from harness.models.tasks import Task, TaskStatus
from harness.models.results import VerificationResult, FailureType
from harness.verification.verifier import Verifier
from harness.agents.repair_agent import RepairAgent

def failure_signature(result: VerificationResult) -> str:
    """Stable signature for loop detection."""
    normalized = re.sub(r"\s+", " ", result.stderr or "").strip()
    tail = normalized[-2000:]
    raw = f"{result.command}|{result.exit_code}|{tail}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()

@dataclass
class RepairOutcome:
    task_id: str
    status: TaskStatus
    attempts: int
    verifications: list[VerificationResult] = field(default_factory=list)
    signatures: list[str] = field(default_factory=list)
    reason: str = ""

class RepairLoop:
    """Repair + reverify loop with hard retry and repeated-failure guards."""

    def __init__(self, repair_agent: RepairAgent, verifier: Verifier,
                 max_retries: int = 3, repeat_limit: int = 3):
        if max_retries < 0:
            raise ValueError("max_retries must be >= 0")
        if repeat_limit < 1:
            raise ValueError("repeat_limit must be >= 1")
        self.repair_agent = repair_agent
        self.verifier = verifier
        self.max_retries = max_retries
        self.repeat_limit = repeat_limit

    def run(self, task: Task, cwd=None, dependency_results=None) -> RepairOutcome:
        attempts = 0
        all_results: list[VerificationResult] = []
        signatures: list[str] = []
        seen = Counter()

        while True:
            results = self.verifier.verify_task(task, cwd=cwd)
            all_results.extend(results)
            if not results:
                task.status = TaskStatus.FAILED
                return RepairOutcome(task.id, TaskStatus.FAILED, attempts, all_results, signatures, "no verification result")

            result = results[-1]
            if result.status == "PASS":
                task.status = TaskStatus.COMPLETED
                return RepairOutcome(task.id, TaskStatus.COMPLETED, attempts, all_results, signatures, "verified")

            sig = failure_signature(result)
            signatures.append(sig)
            seen[sig] += 1

            if seen[sig] >= self.repeat_limit:
                task.status = TaskStatus.FAILED
                return RepairOutcome(
                    task.id, TaskStatus.FAILED, attempts, all_results, signatures,
                    f"ESCALATE: repeated failure signature {sig} ({seen[sig]}x)"
                )

            if result.status == "TIMED_OUT" or result.failure_type == FailureType.TIMEOUT:
                # Timeouts are not repaired indefinitely; the bounded retry policy
                # still permits retries until max_retries.
                pass

            if attempts >= self.max_retries:
                task.status = TaskStatus.FAILED
                return RepairOutcome(task.id, TaskStatus.FAILED, attempts, all_results, signatures, "max repairs exhausted")

            attempts += 1
            self.repair_agent.repair(
                task, result, prior_attempts=attempts - 1,
                dependency_results=dependency_results
            )

def apply_repair_outcome(engine, outcome: RepairOutcome):
    engine.mark(outcome.task_id, outcome.status)
    if outcome.status in {TaskStatus.FAILED, TaskStatus.TIMED_OUT}:
        engine.blocked_propagation()
