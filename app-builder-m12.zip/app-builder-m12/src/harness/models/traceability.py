from pydantic import BaseModel, Field
class RequirementTrace(BaseModel):
    requirement_id: str
    task_ids: list[str] = Field(default_factory=list)
    files: list[str] = Field(default_factory=list)
    commands: list[str] = Field(default_factory=list)
    evidence: list[str] = Field(default_factory=list)
    status: str = "UNVERIFIED"
    missing: list[str] = Field(default_factory=list)
class TraceabilityReport(BaseModel):
    run_id: str = ""
    requirements: list[RequirementTrace] = Field(default_factory=list)
    status: str = "FAIL"
    generated_at: str = ""
