from enum import Enum
from pydantic import BaseModel, Field

class TaskStatus(str, Enum):
    PENDING = "PENDING"
    READY = "READY"
    RUNNING = "RUNNING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"
    TIMED_OUT = "TIMED_OUT"
    BLOCKED = "BLOCKED"

class Task(BaseModel):
    id: str
    description: str
    depends_on: list[str] = Field(default_factory=list)
    files_touched: list[str] = Field(default_factory=list)
    requirements: list[str] = Field(default_factory=list)
    verification: list[str] = Field(default_factory=list)
    status: TaskStatus = TaskStatus.PENDING
