from enum import Enum
from typing import Any
from pydantic import BaseModel, Field
from .spec import AppSpec
from .tasks import Task
from .results import VerificationResult

class RunStatus(str, Enum):
    CREATED = "CREATED"
    SPEC_DONE = "SPEC_DONE"
    PLAN_DONE = "PLAN_DONE"
    BUILDING = "BUILDING"
    VERIFYING = "VERIFYING"
    REPAIRING = "REPAIRING"
    REVIEW_DONE = "REVIEW_DONE"
    PASS = "PASS"
    FAIL = "FAIL"

class CheckpointEvent(BaseModel):
    name: str
    timestamp: str
    payload: dict[str, Any] = Field(default_factory=dict)

class RunState(BaseModel):
    run_id: str
    trace_id: str
    user_request: str
    workspace: str
    spec: AppSpec | None = None
    plan: list[Task] = Field(default_factory=list)
    task_results: dict[str, Any] = Field(default_factory=dict)
    verification_results: list[VerificationResult] = Field(default_factory=list)
    review: dict[str, Any] | None = None
    checkpoints: list[str] = Field(default_factory=list)
    status: RunStatus = RunStatus.CREATED
