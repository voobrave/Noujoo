from pydantic import BaseModel, Field

class Page(BaseModel):
    name: str
    route: str = ""
    entity: str = ""

class Component(BaseModel):
    name: str
    purpose: str = ""

class DataEntity(BaseModel):
    name: str
    fields: list[str] = Field(default_factory=list)

class Stack(BaseModel):
    frontend: str = "FastAPI"
    backend: str = "FastAPI"
    db: str = "SQLite"

class Requirement(BaseModel):
    id: str
    text: str
    must_have: bool = True
    acceptance: str = ""

class AppSpec(BaseModel):
    app_type: str
    stack: Stack = Field(default_factory=Stack)
    pages: list[Page] = Field(default_factory=list)
    components: list[Component] = Field(default_factory=list)
    data_model: list[DataEntity] = Field(default_factory=list)
    requirements: list[Requirement] = Field(default_factory=list)
    must_have: list[str] = Field(default_factory=list)
    explicit_non_goals: list[str] = Field(default_factory=list)
    acceptance_criteria: list[str] = Field(default_factory=list)
