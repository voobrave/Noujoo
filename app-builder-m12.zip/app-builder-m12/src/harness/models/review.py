from datetime import datetime, timezone
from pydantic import BaseModel, Field


class RequirementReview(BaseModel):
    requirement_id: str
    text: str
    must_have: bool = True
    status: str = "FAIL"
    evidence: list[str] = Field(default_factory=list)
    missing: list[str] = Field(default_factory=list)


class ReviewReport(BaseModel):
    run_id: str
    status: str = "FAIL"
    total_requirements: int = 0
    passed_requirements: int = 0
    failed_requirements: int = 0
    requirements: list[RequirementReview] = Field(default_factory=list)
    summary: list[str] = Field(default_factory=list)
    generated_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
