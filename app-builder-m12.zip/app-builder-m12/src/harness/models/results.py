from enum import Enum
from pydantic import BaseModel, Field

class FailureType(str, Enum):
    CODE_ERROR = "CODE_ERROR"
    TEST_FAILURE = "TEST_FAILURE"
    TYPE_ERROR = "TYPE_ERROR"
    DEPENDENCY_ERROR = "DEPENDENCY_ERROR"
    CONFIG_ERROR = "CONFIG_ERROR"
    ENVIRONMENT_ERROR = "ENVIRONMENT_ERROR"
    TIMEOUT = "TIMEOUT"
    UNKNOWN = "UNKNOWN"

class VerificationResult(BaseModel):
    task_id: str
    status: str
    command: str
    exit_code: int
    stdout: str
    stderr: str
    duration_ms: int
    failure_type: FailureType | None = None

class RequirementResult(BaseModel):
    requirement_id: str
    status: str
    evidence: list[str] = Field(default_factory=list)
    missing: list[str] = Field(default_factory=list)
