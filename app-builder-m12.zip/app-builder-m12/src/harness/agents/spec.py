import json
import re
from typing import Any

from ..models.spec import AppSpec, Component, DataEntity, Page, Requirement, Stack
from ..providers.base import LLMProvider

class SpecAgent:
    """Turns a natural-language request into a validated AppSpec candidate."""

    def __init__(self, llm: LLMProvider):
        self.llm = llm

    def generate(self, user_request: str) -> AppSpec:
        system = (
            "You output ONLY valid JSON matching AppSpec. "
            "Infer stack/pages/data_model/requirements/must_have/non_goals/acceptance."
        )
        prompt = (
            "Request:\n" + user_request +
            "\nDefaults: web->React/FastAPI/SQLite; API->FastAPI/SQLite; "
            "todo->FastAPI/SQLite/minimal HTML; unspecified->FastAPI/SQLite. "
            "Requirements must use REQ-001.. sequentially."
        )
        try:
            raw = self.llm.generate(prompt, system)
            return self._parse_llm(raw, user_request)
        except Exception:
            return self._fallback(user_request)

    def _parse_llm(self, raw: str, request: str) -> AppSpec:
        text = raw.strip()
        if text.startswith("```"):
            text = re.sub(r"^```(?:json)?\s*|\s*```$", "", text, flags=re.S)
        data = json.loads(text)
        spec = AppSpec.model_validate(data)
        return self._post_process(spec, request)

    def _post_process(self, spec: AppSpec, request: str) -> AppSpec:
        reqs = []
        for i, req in enumerate(spec.requirements, 1):
            reqs.append(req.model_copy(update={
                "id": f"REQ-{i:03d}",
                "acceptance": req.acceptance or f"Requirement {i} is demonstrably implemented."
            }))
        must = list(dict.fromkeys(spec.must_have or [r.text for r in reqs if r.must_have]))
        non_goals = spec.explicit_non_goals or ["deployment", "mobile-app", "browser-automation"]
        acceptance = spec.acceptance_criteria or [r.acceptance for r in reqs]
        return spec.model_copy(update={
            "requirements": reqs,
            "must_have": must,
            "explicit_non_goals": non_goals,
            "acceptance_criteria": acceptance,
        })

    def _fallback(self, request: str) -> AppSpec:
        text = request.lower()
        is_web = "web" in text or "website" in text or not ("api" in text and "app" not in text)
        stack = Stack(
            frontend="React" if is_web and "todo" not in text else "FastAPI",
            backend="FastAPI",
            db="SQLite",
        )

        concepts = []
        if re.search(r"\bauth(?:entication)?\b|\blogin\b|\bsign[ -]?in\b", text):
            concepts.append(("Authentication", "User authentication"))
        for word, title in [
            ("dashboard", "Dashboard"),
            ("project", "Projects"),
            ("task", "Tasks"),
            ("todo", "Tasks"),
        ]:
            if re.search(rf"\b{word}s?\b", text):
                concepts.append((title, f"{title} functionality"))

        if not concepts:
            concepts = [("App", "Core application functionality")]

        reqs = [
            Requirement(
                id=f"REQ-{i:03d}",
                text=purpose,
                must_have=True,
                acceptance=f"{purpose} is implemented and covered by verification."
            )
            for i, (_, purpose) in enumerate(concepts, 1)
        ]
        pages = [
            Page(name=name, route="/" + name.lower().replace(" ", "-"),
                 entity=name if name != "Authentication" and name != "Dashboard" else "")
            for name, _ in concepts
        ]
        entities = [
            DataEntity(name=name, fields=["id"])
            for name, _ in concepts
            if name not in {"Authentication", "Dashboard"}
        ]
        components = [
            Component(name=name + "Component", purpose=purpose)
            for name, purpose in concepts
        ]
        return AppSpec(
            app_type="web" if is_web else "api",
            stack=stack,
            pages=pages,
            components=components,
            data_model=entities,
            requirements=reqs,
            must_have=[r.text for r in reqs],
            explicit_non_goals=["deployment", "mobile-app", "browser-automation"],
            acceptance_criteria=[r.acceptance for r in reqs],
        )
