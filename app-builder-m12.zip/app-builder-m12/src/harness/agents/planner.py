import re
from ..models.spec import AppSpec
from ..models.tasks import Task
from ..providers.base import LLMProvider

class PlannerAgent:
    def __init__(self, llm: LLMProvider):
        self.llm = llm

    def plan(self, spec: AppSpec) -> list[Task]:
        try:
            # V1 keeps planning deterministic so offline operation is reliable.
            # The LLM is still available as the provider boundary for later richer plans.
            return self._fallback(spec)
        except Exception:
            return self._fallback(spec)

    def _fallback(self, spec: AppSpec) -> list[Task]:
        tasks = []
        def add(description, files, reqs, verify, deps):
            tasks.append(Task(
                id=f"TASK-{len(tasks)+1:03d}",
                description=description,
                files_touched=files,
                requirements=reqs,
                verification=verify,
                depends_on=deps,
            ))

        req_ids = [r.id for r in spec.requirements]
        add("Create application configuration and database/schema foundation",
            ["src/app.py", "src/db.py", "src/models.py"],
            req_ids[:1] or ["REQ-001"], ["python -m pytest -q"], [])

        auth = [r.id for r in spec.requirements if re.search(
            r"auth|login|sign.?in", r.text, re.I)]
        if auth:
            add("Implement authentication infrastructure",
                ["src/auth.py"], auth, ["python -m pytest -q"], ["TASK-001"])

        core = [r.id for r in spec.requirements if r.id not in auth]
        if core:
            add("Implement core entities and CRUD behavior",
                ["src/services.py"], core, ["python -m pytest -q"], [tasks[-1].id])

        page_reqs = core or req_ids
        add("Implement application routes/pages",
            ["src/routes.py"], page_reqs, ["python -m pytest -q"], [tasks[-1].id])

        add("Add end-to-end requirement tests and verification",
            ["tests/test_app.py"], req_ids or ["REQ-001"], ["python -m pytest -q"], [tasks[-1].id])

        return self._normalize(tasks)

    def _normalize(self, tasks: list[Task]) -> list[Task]:
        for i, task in enumerate(tasks, 1):
            task.id = f"TASK-{i:03d}"
            task.depends_on = [
                d for d in task.depends_on
                if re.fullmatch(r"TASK-\d{3}", d) and int(d.split("-")[1]) < i
            ]
            task.files_touched = [
                p.replace("\\", "/").lstrip("/")
                for p in task.files_touched
                if not p.startswith("../") and "/../" not in p
            ]
            if not task.requirements:
                task.requirements = ["REQ-001"]
            if not task.verification:
                task.verification = ["python -m pytest -q"]
        return tasks
