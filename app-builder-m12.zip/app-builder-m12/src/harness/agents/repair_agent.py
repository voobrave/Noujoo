from __future__ import annotations
import json
from typing import Any
from harness.models.tasks import Task
from harness.models.results import VerificationResult
from harness.sandbox.local import LocalSandbox

class RepairAgent:
    """Produces a bounded repair patch for a failed task.

    The repair is constrained to the task's original files_touched. If the
    provider cannot produce a valid patch, the deterministic fallback is a
    no-op marker for a permitted text file, allowing the verifier to provide
    the authoritative evidence.
    """
    def __init__(self, llm: Any, sandbox: LocalSandbox):
        self.llm = llm
        self.sandbox = sandbox

    def _allowed(self, task: Task) -> set[str]:
        return set(task.files_touched)

    def _parse(self, raw: str, allowed: set[str]) -> dict[str, str]:
        data = json.loads(raw)
        if not isinstance(data, dict):
            raise ValueError("repair output must be an object")
        out = {}
        for path, content in data.items():
            if path not in allowed:
                raise PermissionError(f"repair attempted disallowed file: {path}")
            if not isinstance(content, str):
                raise ValueError(f"content for {path} must be a string")
            out[path] = content
        return out

    def repair(self, task: Task, verification: VerificationResult,
               prior_attempts: int = 0, dependency_results=None) -> dict[str, str]:
        allowed = self._allowed(task)
        if not allowed:
            raise ValueError(f"{task.id}: no repairable files")

        prompt = json.dumps({
            "role": "RepairAgent",
            "instruction": (
                "Return only a JSON object mapping permitted relative paths "
                "to complete replacement file contents. Repair the reported failure."
            ),
            "task": task.model_dump(mode="json"),
            "verification": verification.model_dump(mode="json"),
            "attempt": prior_attempts + 1,
            "allowed_files": sorted(allowed),
            "dependency_results": dependency_results or [],
        }, sort_keys=True)

        raw = self.llm.generate(prompt)
        try:
            files = self._parse(raw, allowed)
        except PermissionError:
            # Scope violations are security/correctness failures and must not
            # be silently converted into a no-op repair.
            raise
        except Exception:
            # Deterministic offline fallback: do not invent new files or modify
            # anything outside the task scope. The verifier remains authoritative.
            files = {}

        for path, content in files.items():
            self.sandbox.write_text(path, content)
        return files
