"""Evidence-based final requirement review for an App-Builder Harness run."""
from pathlib import Path, PurePosixPath
from typing import Any

from harness.models.review import RequirementReview, ReviewReport
from harness.models.spec import AppSpec
from harness.models.traceability import TraceabilityReport


class RequirementReviewer:
    """Review requirements against traceability and files actually present.

    This reviewer does not infer success from generated code or agent claims. It
    requires traceability links, existing workspace files, and passing command
    evidence. Functional correctness still depends on the verifier's tests.
    """

    def review(
        self,
        run_id: str,
        spec: AppSpec,
        traceability: TraceabilityReport | dict[str, Any],
        workspace: Path | str,
    ) -> ReviewReport:
        if isinstance(traceability, dict):
            traceability = TraceabilityReport.model_validate(traceability)
        root = Path(workspace).resolve()
        traces = {item.requirement_id: item for item in traceability.requirements}
        reviews: list[RequirementReview] = []

        for req in spec.requirements:
            missing: list[str] = []
            evidence: list[str] = []
            trace = traces.get(req.id)

            if trace is None:
                missing.append("no traceability record for requirement")
            else:
                if trace.status != "PASS":
                    missing.append("traceability status is not PASS")
                if not trace.task_ids:
                    missing.append("no task linked")
                if not trace.commands:
                    missing.append("no verification command recorded")
                if not trace.evidence:
                    missing.append("no passing command evidence recorded")

                safe_files: list[Path] = []
                for rel in trace.files:
                    candidate_path = PurePosixPath(rel)
                    if candidate_path.is_absolute() or ".." in candidate_path.parts:
                        missing.append(f"unsafe file path: {rel}")
                        continue
                    candidate = (root / Path(*candidate_path.parts)).resolve()
                    try:
                        candidate.relative_to(root)
                    except ValueError:
                        missing.append(f"file escapes workspace: {rel}")
                        continue
                    safe_files.append(candidate)
                    if not candidate.is_file():
                        missing.append(f"mapped file does not exist: {rel}")

                for item in trace.evidence:
                    if "exit_code=0" in item:
                        evidence.append(item)
                    else:
                        missing.append("evidence does not prove exit_code=0")

            if not req.acceptance.strip():
                missing.append("requirement has no acceptance statement")

            # Keep reports easy to scan and avoid duplicate messages.
            missing = list(dict.fromkeys(missing))
            reviews.append(RequirementReview(
                requirement_id=req.id,
                text=req.text,
                must_have=req.must_have,
                status="PASS" if not missing else "FAIL",
                evidence=evidence,
                missing=missing,
            ))

        passed = sum(item.status == "PASS" for item in reviews)
        failed = len(reviews) - passed
        summary = []
        if failed == 0 and reviews:
            summary.append("Every requirement has traceable, passing verification evidence.")
        elif not reviews:
            summary.append("The specification contains no requirements to review.")
        else:
            summary.append(f"{failed} requirement(s) are missing required evidence or links.")
        summary.append("This review validates recorded evidence and file presence; it does not replace runtime or acceptance testing.")

        return ReviewReport(
            run_id=run_id,
            status="PASS" if reviews and failed == 0 else "FAIL",
            total_requirements=len(reviews),
            passed_requirements=passed,
            failed_requirements=failed,
            requirements=reviews,
            summary=summary,
        )

    def save(self, report: ReviewReport, path: Path | str) -> Path:
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(report.model_dump_json(indent=2), encoding="utf-8")
        return target
