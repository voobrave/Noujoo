import json
from .environment import mobile_environment_report

def main() -> None:
    print(json.dumps(mobile_environment_report(), indent=2))

if __name__ == "__main__":
    main()
