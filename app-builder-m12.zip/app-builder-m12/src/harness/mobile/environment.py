import shutil
import subprocess
from dataclasses import dataclass

@dataclass
class ToolStatus:
    name: str
    available: bool
    version: str = ""

def check_tool(name: str, version_args: list[str] | None = None) -> ToolStatus:
    path = shutil.which(name)
    if not path:
        return ToolStatus(name, False, "")
    args = version_args or ["--version"]
    try:
        result = subprocess.run([path, *args], capture_output=True, text=True, timeout=5)
        output = (result.stdout or result.stderr).strip().splitlines()
        return ToolStatus(name, result.returncode == 0, output[0] if output else "")
    except (OSError, subprocess.TimeoutExpired):
        return ToolStatus(name, False, "")

def mobile_environment_report() -> dict:
    tools = {}
    for name in ("python", "pip", "git", "java", "adb", "flutter", "dart"):
        tools[name] = check_tool(name).__dict__
    return {
        "platform": "android/termux-or-linux-userspace",
        "tools": tools,
        "apk_build_ready": bool(
            tools["flutter"]["available"] and tools["dart"]["available"]
        ),
    }
