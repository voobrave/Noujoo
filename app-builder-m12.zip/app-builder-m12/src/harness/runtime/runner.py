from __future__ import annotations

import json
import os
import shlex
import subprocess
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Sequence


class RuntimeError(ValueError):
    """Raised when a runtime request is invalid or escapes its workspace."""


@dataclass
class RuntimeResult:
    command: list[str]
    cwd: str
    status: str
    exit_code: int
    stdout: str
    stderr: str
    duration_ms: int
    timed_out: bool
    started_at: str
    finished_at: str

    def to_dict(self) -> dict:
        return asdict(self)


class RuntimeRunner:
    """Run a project command without a shell and save reproducible evidence.

    This is a workspace boundary, not an OS-level security sandbox. Do not run
    untrusted code on a machine containing secrets or important personal files.
    """

    def __init__(self, workspace: str | Path, timeout_s: int = 60,
                 output_limit: int = 12000, evidence_dir: str | Path | None = None):
        self.workspace = Path(workspace).resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)
        if timeout_s < 1 or timeout_s > 3600:
            raise ValueError("timeout_s must be between 1 and 3600")
        if output_limit < 100:
            raise ValueError("output_limit must be at least 100")
        self.timeout_s = timeout_s
        self.output_limit = output_limit
        self.evidence_dir = Path(evidence_dir).resolve() if evidence_dir else self.workspace / ".harness" / "runtime"
        self.evidence_dir.mkdir(parents=True, exist_ok=True)

    def _cwd(self, cwd: str | Path | None) -> Path:
        target = (self.workspace / cwd).resolve() if cwd is not None else self.workspace
        try:
            target.relative_to(self.workspace)
        except ValueError as exc:
            raise RuntimeError(f"working directory escapes workspace: {cwd}") from exc
        if not target.is_dir():
            raise RuntimeError(f"working directory does not exist: {target}")
        return target

    @staticmethod
    def _argv(command: str | Sequence[str]) -> list[str]:
        argv = shlex.split(command) if isinstance(command, str) else list(command)
        if not argv or not all(isinstance(arg, str) and arg for arg in argv):
            raise RuntimeError("command must be a non-empty string or sequence of strings")
        if any("\x00" in arg for arg in argv):
            raise RuntimeError("NUL bytes are not allowed in command arguments")
        return argv

    def run(self, command: str | Sequence[str], cwd: str | Path | None = None,
            env: dict[str, str] | None = None, label: str = "runtime") -> RuntimeResult:
        argv = self._argv(command)
        run_cwd = self._cwd(cwd)
        started_at = datetime.now(timezone.utc).isoformat()
        started = time.monotonic()
        status, exit_code, stdout, stderr, timed_out = "FAIL", -1, "", "", False
        safe_env = {"PATH": os.environ.get("PATH", ""), "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8"}
        if env:
            for key, value in env.items():
                if not isinstance(key, str) or not isinstance(value, str) or "=" in key or "\x00" in key or "\x00" in value:
                    raise RuntimeError("invalid environment variable")
                safe_env[key] = value
        try:
            completed = subprocess.run(
                argv, cwd=str(run_cwd), env=safe_env, shell=False,
                capture_output=True, text=True, timeout=self.timeout_s,
                check=False,
            )
            exit_code = completed.returncode
            stdout, stderr = completed.stdout or "", completed.stderr or ""
            status = "PASS" if exit_code == 0 else "FAIL"
        except subprocess.TimeoutExpired as exc:
            timed_out, status, exit_code = True, "TIMED_OUT", -1
            stdout = self._decode(exc.stdout)
            stderr = self._decode(exc.stderr) + "\nRuntimeTimeout"
        except OSError as exc:
            status, exit_code, stderr = "STARTUP_ERROR", -1, f"{type(exc).__name__}: {exc}"
        finished_at = datetime.now(timezone.utc).isoformat()
        result = RuntimeResult(
            command=argv, cwd=str(run_cwd.relative_to(self.workspace) or "."),
            status=status, exit_code=exit_code,
            stdout=stdout[-self.output_limit:], stderr=stderr[-self.output_limit:],
            duration_ms=int((time.monotonic() - started) * 1000), timed_out=timed_out,
            started_at=started_at, finished_at=finished_at,
        )
        safe_label = "".join(c for c in label if c.isalnum() or c in "-_" )[:60] or "runtime"
        target = self.evidence_dir / f"{int(time.time() * 1000)}-{safe_label}.json"
        temp = target.with_suffix(".json.tmp")
        temp.write_text(json.dumps(result.to_dict(), indent=2), encoding="utf-8")
        temp.replace(target)
        return result

    @staticmethod
    def _decode(value) -> str:
        if value is None:
            return ""
        return value.decode("utf-8", errors="replace") if isinstance(value, bytes) else str(value)

    def check_python_project(self, cwd: str | Path | None = None) -> list[RuntimeResult]:
        """Run compile check and the project's tests, stopping on compile failure."""
        results = [self.run([os.environ.get("PYTHON", "python"), "-m", "compileall", "-q", "."], cwd, label="compile")]
        if results[-1].status == "PASS":
            results.append(self.run([os.environ.get("PYTHON", "python"), "-m", "pytest", "-q"], cwd, label="tests"))
        return results
