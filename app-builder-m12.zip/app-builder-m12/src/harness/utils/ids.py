import secrets
import uuid

def new_run_id(n: int = 1) -> str:
    return f"run_{n:03d}"

def new_trace_id() -> str:
    return uuid.uuid4().hex

def new_task_id(n: int) -> str:
    return f"TASK-{n:03d}"

def new_requirement_id(n: int) -> str:
    return f"REQ-{n:03d}"

def new_test_id(n: int) -> str:
    return f"TEST-{n:03d}"
