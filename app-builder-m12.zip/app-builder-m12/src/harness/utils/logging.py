import json
from datetime import datetime, timezone
from pathlib import Path

def emit(base, run_id, trace_id, stage, agent, task_id="", status="",
         duration_ms=0, model="", tokens=0, tool="", error=""):
    path = Path(base) / run_id / "events.log"
    path.parent.mkdir(parents=True, exist_ok=True)
    event = {
        "run_id": run_id, "trace_id": trace_id, "stage": stage,
        "agent": agent, "task_id": task_id,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "duration_ms": duration_ms, "model": model, "tokens": tokens,
        "tool": tool, "status": status, "error": error,
    }
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, separators=(",", ":")) + "\n")
