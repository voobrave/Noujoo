from pathlib import PurePosixPath
from harness.sandbox.local import LocalSandbox

def _validate(path):
    p = PurePosixPath(path)
    if p.is_absolute() or ".." in p.parts or str(p) in ("", "."):
        raise PermissionError(f"unsafe path: {path}")
    return p.as_posix()

class FileTools:
    def __init__(self, sandbox: LocalSandbox, allowed_files):
        self.sandbox = sandbox
        self.allowed = {_validate(x) for x in allowed_files}

    def _check(self, path):
        path = _validate(path)
        if path not in self.allowed:
            raise PermissionError(f"file not allowed for this task: {path}")
        return path

    def read(self, path):
        return self.sandbox.read_text(self._check(path))

    def write(self, path, content):
        self.sandbox.write_text(self._check(path), content)

    def list_allowed(self):
        return sorted(self.allowed)
