from __future__ import annotations
import time
from pathlib import Path
from harness.models.results import VerificationResult, FailureType
from harness.sandbox.local import LocalSandbox
from harness.verification.classifier import classify_failure

class Verifier:
    def __init__(self, sandbox: LocalSandbox, timeout_s: int = 120):
        self.sandbox = sandbox
        self.timeout_s = timeout_s

    def _run(self, command: str, cwd: str | Path | None = None):
        started = time.monotonic()
        result = self.sandbox.execute(command, cwd=cwd, timeout_s=self.timeout_s)
        duration = int((time.monotonic() - started) * 1000)
        return result, duration

    def verify(self, task_id: str, command: str, cwd: str | Path | None = None) -> VerificationResult:
        result, duration = self._run(command, cwd)
        stdout = (result.get("stdout") or "")[-4000:]
        stderr = (result.get("stderr") or "")[-4000:]
        exit_code = result.get("exit_code", -1)
        timed_out = "TimeoutExpired" in stderr
        if timed_out:
            status = "TIMED_OUT"
            failure = FailureType.TIMEOUT
        elif exit_code == 0:
            status = "PASS"
            failure = None
        else:
            status = "FAIL"
            failure = classify_failure(exit_code, stdout, stderr, duration, timed_out)
        return VerificationResult(
            task_id=task_id,
            status=status,
            command=command,
            exit_code=exit_code,
            stdout=stdout,
            stderr=stderr,
            duration_ms=duration,
            failure_type=failure,
        )

    def verify_task(self, task, cwd: str | Path | None = None):
        results = []
        commands = list(task.verification)
        if not commands:
            commands = ["pytest -q"]
        req = Path(cwd or self.sandbox.root) / "requirements.txt"
        if req.exists():
            install = self.verify(task.id, "python -m pip install -r requirements.txt", cwd)
            results.append(install)
            if install.status != "PASS":
                return results
        for command in commands:
            result = self.verify(task.id, command, cwd)
            results.append(result)
            if result.status != "PASS":
                break
        return results
