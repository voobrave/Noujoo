from datetime import datetime, timezone
from pathlib import Path
from harness.models.traceability import RequirementTrace, TraceabilityReport
class TraceabilityEngine:
    def build(self, run_id, spec, tasks, verification_results):
        tasks = list(tasks)
        by_task = {}
        for result in verification_results:
            by_task.setdefault(result.task_id, []).append(result)
        traces, all_pass = [], True
        for req in spec.requirements:
            matched = [t for t in tasks if req.id in t.requirements]
            task_ids = [t.id for t in matched]
            files = sorted({f for t in matched for f in t.files_touched})
            commands, evidence, missing = [], [], []
            for task in matched:
                commands.extend(task.verification)
                for result in by_task.get(task.id, []):
                    if result.status == "PASS" and result.exit_code == 0:
                        evidence.append(f"{task.id}: command={result.command!r}; exit_code=0; stdout={result.stdout[-4000:]!r}; stderr={result.stderr[-4000:]!r}")
            if not task_ids: missing.append("no task maps to requirement")
            if not files: missing.append("no files mapped")
            if not commands: missing.append("no verification command mapped")
            if not evidence: missing.append("no passing verification evidence")
            status = "PASS" if not missing else "FAIL"
            all_pass = all_pass and status == "PASS"
            traces.append(RequirementTrace(requirement_id=req.id, task_ids=sorted(set(task_ids)),
                files=files, commands=sorted(set(commands)), evidence=evidence, status=status, missing=missing))
        return TraceabilityReport(run_id=run_id, requirements=traces,
            status="PASS" if all_pass else "FAIL", generated_at=datetime.now(timezone.utc).isoformat())
    def save(self, report, path: Path):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(report.model_dump_json(indent=2), encoding="utf-8")
