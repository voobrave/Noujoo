from harness.verification.classifier import classify_failure

class FailureClassifier:
    classify = staticmethod(classify_failure)
