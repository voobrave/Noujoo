from __future__ import annotations
import re
from harness.models.results import FailureType

def classify_failure(exit_code: int, stdout: str = "", stderr: str = "",
                     duration_ms: int = 0, timed_out: bool = False) -> FailureType:
    text = f"{stdout}\n{stderr}"
    if timed_out or "TimeoutExpired" in text or duration_ms > 120000:
        return FailureType.TIMEOUT
    if exit_code == 0:
        return FailureType.UNKNOWN
    if re.search(r"ModuleNotFoundError|ImportError", text):
        return FailureType.DEPENDENCY_ERROR
    if re.search(r"SyntaxError", text):
        return FailureType.CODE_ERROR
    if re.search(r"(ValidationError|mypy|type error|TypeError)", text, re.I):
        return FailureType.TYPE_ERROR
    if re.search(r"(pytest|FAILED|AssertionError)", text):
        return FailureType.TEST_FAILURE
    if re.search(r"(config|environment variable|missing.*config|KeyError)", text, re.I):
        return FailureType.CONFIG_ERROR
    if re.search(r"(ETIMEDOUT|ENOTFOUND|EAI_AGAIN|registry.*503|503 Service)", text, re.I):
        return FailureType.ENVIRONMENT_ERROR
    return FailureType.UNKNOWN
