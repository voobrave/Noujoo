import re
from ..models.spec import AppSpec
from ..models.run import RunStatus

_REQ_RE = re.compile(r"^REQ-\d{3}$")

class SpecValidator:
    def validate(self, spec: AppSpec) -> list[str]:
        errors: list[str] = []

        if not spec.app_type.strip():
            errors.append("app_type must be non-empty")
        if not spec.stack.frontend.strip():
            errors.append("stack.frontend must be non-empty")
        if not spec.stack.backend.strip():
            errors.append("stack.backend must be non-empty")
        if not spec.stack.db.strip():
            errors.append("stack.db must be non-empty")
        if not spec.requirements:
            errors.append("requirements must contain at least one item")
        if not spec.acceptance_criteria:
            errors.append("acceptance_criteria must contain at least one item")

        ids = [r.id for r in spec.requirements]
        if len(ids) != len(set(ids)):
            errors.append("requirement IDs must be unique")
        if any(not _REQ_RE.match(x) for x in ids):
            errors.append("requirement IDs must match REQ-XXX")

        entity_names = {e.name.lower() for e in spec.data_model}
        for page in spec.pages:
            if page.entity and page.entity.lower() not in entity_names:
                errors.append(
                    f"page entity '{page.entity}' is not present in data_model"
                )

        non_goals = [x.lower() for x in spec.explicit_non_goals]
        for req in spec.requirements:
            if any(req.text.lower() in ng or ng in req.text.lower() for ng in non_goals):
                errors.append(
                    f"requirement conflicts with explicit_non_goal: {req.id}"
                )

        if any(
            re.search(r"\b(api|backend|server)\b", r.text, re.I)
            for r in spec.requirements
        ) and not spec.stack.backend.strip():
            errors.append("backend is required when a requirement mentions API/backend")

        texts = [r.text.strip().casefold() for r in spec.requirements]
        if len(texts) != len(set(texts)):
            errors.append("duplicate requirement text")

        for must in spec.must_have:
            if not any(must.casefold() in r.text.casefold() or
                       r.text.casefold() in must.casefold()
                       for r in spec.requirements):
                errors.append(f"must_have item has no matching requirement: {must}")

        if not spec.explicit_non_goals:
            errors.append("explicit_non_goals must be non-empty")

        return errors

def spec_stage(store, run_id, llm, user_request=None, max_attempts=2):
    """Generate, validate, checkpoint 001-spec.json, and update run state."""
    state = store.load(run_id)
    request = user_request if user_request is not None else state.user_request
    agent = SpecAgent(llm)
    validator = SpecValidator()
    last_errors = []

    for attempt in range(1, max_attempts + 1):
        prompt_request = request
        if last_errors:
            prompt_request += "\nPrevious validation errors to fix:\n" + "\n".join(last_errors)
        spec = agent.generate(prompt_request)
        errors = validator.validate(spec)
        if not errors:
            state.spec = spec
            state.status = RunStatus.SPEC_DONE
            store.checkpoint(state, "001-spec.json", spec.model_dump(mode="json"))
            store.save(state)
            return spec
        last_errors = errors

    raise ValueError("Spec validation failed after retries: " + "; ".join(last_errors))

from .spec_validator import SpecValidator
from ..agents.spec import SpecAgent
