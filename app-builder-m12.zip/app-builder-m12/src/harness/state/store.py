import json
from datetime import datetime, timezone
from pathlib import Path
from ..models.run import RunState

class RunStore:
    def __init__(self, base: Path | str = Path("runs")):
        self.base = Path(base)
        self.base.mkdir(parents=True, exist_ok=True)

    def _run_dir(self, run_id: str) -> Path:
        return self.base / run_id

    def create_run(self, user_request: str) -> RunState:
        run_id = self._next_run_id()
        trace_id = datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S%f")
        run_dir = self._run_dir(run_id)
        (run_dir / "checkpoints").mkdir(parents=True)
        (run_dir / "workspace").mkdir()
        state = RunState(
            run_id=run_id, trace_id=trace_id,
            user_request=user_request,
            workspace=str(run_dir / "workspace"),
        )
        self.save(state)
        return state

    def _next_run_id(self) -> str:
        nums = []
        for p in self.base.glob("run_*"):
            try:
                nums.append(int(p.name.split("_")[1]))
            except (ValueError, IndexError):
                pass
        return f"run_{max(nums, default=0)+1:03d}"

    def save(self, state: RunState) -> None:
        """Atomically persist state so a crash cannot leave a half-written JSON file."""
        path = self._run_dir(state.run_id)
        path.mkdir(parents=True, exist_ok=True)
        target = path / "state.json"
        temp = path / "state.json.tmp"
        temp.write_text(state.model_dump_json(indent=2), encoding="utf-8")
        temp.replace(target)

    def load(self, run_id: str) -> RunState:
        return RunState.model_validate_json(
            (self._run_dir(run_id) / "state.json").read_text(encoding="utf-8")
        )

    def checkpoint(self, state: RunState, name: str, payload: dict) -> Path:
        path = self._run_dir(state.run_id) / "checkpoints" / name
        path.parent.mkdir(parents=True, exist_ok=True)
        serialized = json.dumps(payload, indent=2, default=str)
        temp = path.with_suffix(path.suffix + ".tmp")
        temp.write_text(serialized, encoding="utf-8")
        temp.replace(path)
        if name not in state.checkpoints:
            state.checkpoints.append(name)
        self.save(state)
        # Full state snapshots let recovery reconstruct a run if state.json is damaged.
        snapshot_name = f"state-{Path(name).stem}.json"
        snapshot_path = path.parent / snapshot_name
        snapshot_tmp = snapshot_path.with_suffix(snapshot_path.suffix + ".tmp")
        snapshot_tmp.write_text(state.model_dump_json(indent=2), encoding="utf-8")
        snapshot_tmp.replace(snapshot_path)
        return path

    def list_runs(self) -> list[str]:
        return sorted(p.name for p in self.base.glob("run_*") if p.is_dir())

    def resume(self, run_id: str) -> RunState:
        return self.load(run_id)
