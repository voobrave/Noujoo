from __future__ import annotations

import json
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

REQUIRED_FILES = [
    "pyproject.toml", "README.md", "M9_RECOVERY.md", "M10_RUNTIME.md",
    "M11_CLI_BENCHMARKS.md", "M12_FINAL_GATE.md", "src/harness/runtime/runner.py",
    "src/harness/recovery/manager.py", "src/harness/cli.py",
    "src/harness/agents/reviewer.py", "src/harness/orchestration/review.py",
]


def run_final_gate(root: str | Path, run_tests: bool = True,
                   timeout_s: int = 300) -> dict:
    """Check release structure, Python syntax, and optionally the full test suite."""
    root = Path(root).resolve()
    started = time.monotonic()
    checks: list[dict] = []

    def add(name: str, passed: bool, details: str = "") -> None:
        checks.append({"name": name, "passed": bool(passed), "details": details})

    add("project_root_exists", root.is_dir(), str(root))
    missing = [name for name in REQUIRED_FILES if not (root / name).is_file()]
    add("required_release_files", not missing, "missing: " + ", ".join(missing) if missing else "all present")
    test_files = sorted((root / "tests").glob("test_*.py")) if (root / "tests").is_dir() else []
    add("automated_tests_present", bool(test_files), f"{len(test_files)} test files")

    source_root = root / "src"
    compile_result = subprocess.run(
        [sys.executable, "-m", "compileall", "-q", str(source_root)],
        cwd=str(root), capture_output=True, text=True, timeout=timeout_s,
    ) if source_root.is_dir() else None
    compile_ok = bool(compile_result and compile_result.returncode == 0)
    compile_details = "Python compileall passed" if compile_ok else (
        (compile_result.stderr or compile_result.stdout)[-4000:] if compile_result else "src directory missing"
    )
    add("python_compile", compile_ok, compile_details)

    if run_tests:
        try:
            result = subprocess.run(
                [sys.executable, "-m", "pytest", "-q"], cwd=str(root),
                capture_output=True, text=True, timeout=timeout_s,
            )
            test_ok = result.returncode == 0
            test_details = (result.stdout + "\n" + result.stderr).strip()[-8000:]
            add("full_test_suite", test_ok, test_details)
        except subprocess.TimeoutExpired as exc:
            add("full_test_suite", False, f"timed out after {timeout_s}s: {exc}")
    else:
        add("full_test_suite", False, "not run (explicitly disabled)")

    failed = [check["name"] for check in checks if not check["passed"]]
    return {
        "schema_version": 1,
        "gate": "app-builder-final-release",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "project_root": str(root),
        "status": "PASS" if not failed else "FAIL",
        "checks_passed": sum(check["passed"] for check in checks),
        "checks_total": len(checks),
        "duration_ms": int((time.monotonic() - started) * 1000),
        "failed_checks": failed,
        "checks": checks,
        "limitations": [
            "This gate checks project structure, syntax, and tests; it does not prove the generated app meets every user's intent.",
            "Runtime workspace path checks are not an OS-level sandbox.",
            "External API, Firebase, mobile APK, and production deployment behavior require separate environment-specific tests.",
        ],
    }


def write_gate_report(report: dict, output: str | Path) -> Path:
    target = Path(output).resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    temp = target.with_suffix(target.suffix + ".tmp")
    temp.write_text(json.dumps(report, indent=2), encoding="utf-8")
    temp.replace(target)
    return target
