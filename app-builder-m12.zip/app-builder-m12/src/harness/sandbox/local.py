import subprocess
import time
from pathlib import Path

class LocalSandbox:
    def __init__(self, root: Path | str):
        self.root = Path(root).resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _safe(self, rel: str | Path) -> Path:
        target = (self.root / rel).resolve()
        try:
            target.relative_to(self.root)
        except ValueError:
            raise PermissionError(f"path escapes workspace root: {rel}")
        return target

    def create_workspace(self, run_id: str) -> Path:
        path = self._safe(run_id)
        path.mkdir(parents=True, exist_ok=True)
        return path

    def write_text(self, rel: str, content: str) -> Path:
        return self.write_file(rel, content)

    def read_text(self, rel: str) -> str:
        return self.read_file(rel)

    def write_file(self, rel: str, content: str) -> Path:
        path = self._safe(rel)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return path

    def read_file(self, rel: str) -> str:
        return self._safe(rel).read_text(encoding="utf-8")

    def list_files(self, rel: str = ".") -> list[str]:
        base = self._safe(rel)
        return sorted(str(p.relative_to(self.root)) for p in base.rglob("*") if p.is_file())

    def delete_file(self, rel: str) -> None:
        self._safe(rel).unlink()

    def execute(self, cmd, cwd: Path | None = None, timeout_s: int = 120) -> dict:
        start = time.monotonic()
        shell = isinstance(cmd, str)
        run_cwd = self.root if cwd is None else self._safe(cwd)
        if not run_cwd.is_dir():
            raise NotADirectoryError(str(run_cwd))
        result = None
        try:
            result = subprocess.run(
                cmd, cwd=str(run_cwd), shell=shell,
                capture_output=True, text=True, timeout=timeout_s
            )
            return {
                "exit_code": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "duration_ms": int((time.monotonic()-start)*1000),
            }
        except subprocess.TimeoutExpired as exc:
            return {
                "exit_code": -1,
                "stdout": exc.stdout or "",
                "stderr": (exc.stderr or "") + "\nTimeoutExpired",
                "duration_ms": int((time.monotonic()-start)*1000),
            }
