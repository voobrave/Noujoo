"""Local benchmark helpers and reports."""
