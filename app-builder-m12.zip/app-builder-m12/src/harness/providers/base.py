from abc import ABC, abstractmethod
from collections.abc import Iterator
from pydantic import BaseModel

class LLMProvider(ABC):
    @abstractmethod
    def generate(self, prompt: str, system: str = "") -> str: ...

    @abstractmethod
    def generate_structured(self, prompt: str, schema: type[BaseModel]) -> BaseModel: ...

    @abstractmethod
    def stream(self, prompt: str) -> Iterator[str]: ...
