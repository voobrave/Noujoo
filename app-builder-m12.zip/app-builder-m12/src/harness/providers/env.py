import os
from collections.abc import Iterator
from pydantic import BaseModel
from .base import LLMProvider
from .mock import MockProvider

class EnvOpenAICompatibleProvider(LLMProvider):
    def __init__(self, api_key: str | None = None, base_url: str | None = None):
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        self.base_url = base_url or os.getenv("OPENAI_BASE_URL")
        self._fallback = MockProvider()

    def generate(self, prompt: str, system: str = "") -> str:
        # V1 deliberately falls back offline; HTTP integration is added only when
        # an explicitly configured compatible endpoint is available.
        return self._fallback.generate(prompt, system)

    def generate_structured(self, prompt: str, schema: type[BaseModel]) -> BaseModel:
        return self._fallback.generate_structured(prompt, schema)

    def stream(self, prompt: str) -> Iterator[str]:
        yield from self._fallback.stream(prompt)
