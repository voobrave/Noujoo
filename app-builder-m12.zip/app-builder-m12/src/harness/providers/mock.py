import json
from collections.abc import Iterator
from pydantic import BaseModel
from .base import LLMProvider

class MockProvider(LLMProvider):
    def generate(self, prompt: str, system: str = "") -> str:
        return f"MOCK_RESPONSE: {prompt[:200]}"

    def generate_structured(self, prompt: str, schema: type[BaseModel]) -> BaseModel:
        fields = schema.model_fields
        data = {}
        for name, field in fields.items():
            if field.default is not None and field.default is not ...:
                continue
            if name == "app_type":
                data[name] = "web"
            elif name == "id":
                data[name] = "REQ-001"
            elif name == "text":
                data[name] = "Generated requirement"
            elif name == "description":
                data[name] = "Generated task"
            elif name == "status":
                data[name] = "PENDING"
            else:
                data[name] = "" if field.annotation is str else []
        return schema.model_validate(data)

    def stream(self, prompt: str) -> Iterator[str]:
        yield from self.generate(prompt).split()
