from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

from harness.mobile.environment import mobile_environment_report
from harness.runtime import RuntimeRunner
from harness.state.store import RunStore
from harness.release import run_final_gate, write_gate_report


def _json(data) -> None:
    print(json.dumps(data, indent=2, default=str))


def cmd_doctor(_args) -> int:
    report = mobile_environment_report()
    report["python_version"] = sys.version.split()[0]
    report["project_runtime_available"] = True
    _json(report)
    return 0


def cmd_new(args) -> int:
    state = RunStore(args.runs_dir).create_run(args.request)
    _json({"run_id": state.run_id, "workspace": state.workspace, "status": state.status})
    return 0


def cmd_runs(args) -> int:
    store = RunStore(args.runs_dir)
    _json([{"run_id": rid, "state_file_exists": (Path(args.runs_dir) / rid / "state.json").is_file()} for rid in store.list_runs()])
    return 0


def cmd_recover(args) -> int:
    from harness.recovery import RecoveryManager
    outcome = RecoveryManager(RunStore(args.runs_dir)).recover(args.run_id)
    _json({"run_id": outcome.state.run_id, "recovered": outcome.recovered,
           "source": outcome.source, "warnings": outcome.warnings,
           "completed_task_ids": outcome.completed_task_ids,
           "resumable_task_ids": outcome.resumable_task_ids})
    return 0


def cmd_runtime(args) -> int:
    workspace = Path(args.workspace).resolve()
    if not workspace.is_dir():
        print(f"Workspace does not exist: {workspace}", file=sys.stderr)
        return 2
    result = RuntimeRunner(workspace, timeout_s=args.timeout).run(args.command, cwd=args.cwd, label=args.label)
    _json(result.to_dict())
    return 0 if result.status == "PASS" else 1


def cmd_test(args) -> int:
    workspace = Path(args.workspace).resolve()
    if not workspace.is_dir():
        print(f"Workspace does not exist: {workspace}", file=sys.stderr)
        return 2
    results = RuntimeRunner(workspace, timeout_s=args.timeout).check_python_project()
    _json([result.to_dict() for result in results])
    return 0 if results and all(r.status == "PASS" for r in results) else 1


def cmd_benchmark(args) -> int:
    workspace = Path(args.workspace).resolve()
    workspace.mkdir(parents=True, exist_ok=True)
    runner = RuntimeRunner(workspace, timeout_s=args.timeout)
    durations, failures = [], []
    for i in range(args.iterations):
        result = runner.run([sys.executable, "-c", "print('benchmark-ok')"], label=f"benchmark-{i+1}")
        durations.append(result.duration_ms)
        if result.status != "PASS":
            failures.append({"iteration": i + 1, "status": result.status, "stderr": result.stderr})
    ordered = sorted(durations)
    report = {
        "benchmark": "python_startup_smoke",
        "iterations": args.iterations,
        "passed": args.iterations - len(failures),
        "failed": len(failures),
        "duration_ms": durations,
        "mean_duration_ms": round(sum(durations) / len(durations), 2),
        "median_duration_ms": ordered[len(ordered) // 2],
        "failures": failures,
        "note": "Informational local microbenchmark; timings vary by device and environment.",
    }
    output = Path(args.output).resolve() if args.output else workspace / ".harness" / "benchmark.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    temp = output.with_suffix(output.suffix + ".tmp")
    temp.write_text(json.dumps(report, indent=2), encoding="utf-8")
    temp.replace(output)
    report["report_path"] = str(output)
    _json(report)
    return 0 if not failures else 1



def cmd_gate(args) -> int:
    workspace = Path(args.workspace).resolve()
    report = run_final_gate(workspace, run_tests=not args.skip_tests, timeout_s=args.timeout)
    output = Path(args.output).resolve() if args.output else workspace / ".harness" / "final-gate.json"
    write_gate_report(report, output)
    report["report_path"] = str(output)
    _json(report)
    return 0 if report["status"] == "PASS" else 1


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="app-builder", description="Local App-Builder Harness utilities")
    sub = parser.add_subparsers(dest="subcommand", required=True)
    p = sub.add_parser("doctor", help="Report local/mobile tool availability")
    p.set_defaults(func=cmd_doctor)
    p = sub.add_parser("new", help="Create a persistent run and workspace")
    p.add_argument("request")
    p.add_argument("--runs-dir", default="runs")
    p.set_defaults(func=cmd_new)
    p = sub.add_parser("runs", help="List persisted runs")
    p.add_argument("--runs-dir", default="runs")
    p.set_defaults(func=cmd_runs)
    p = sub.add_parser("recover", help="Recover a saved run after interruption")
    p.add_argument("run_id")
    p.add_argument("--runs-dir", default="runs")
    p.set_defaults(func=cmd_recover)
    p = sub.add_parser("runtime", help="Run a command in a workspace without a shell")
    p.add_argument("--workspace", required=True)
    p.add_argument("--cwd", default=None)
    p.add_argument("--timeout", type=int, default=60)
    p.add_argument("--label", default="cli-runtime")
    p.add_argument("command", nargs=argparse.REMAINDER, help="Command and arguments after --")
    p.set_defaults(func=cmd_runtime)
    p = sub.add_parser("test", help="Compile and test a Python project")
    p.add_argument("--workspace", required=True)
    p.add_argument("--timeout", type=int, default=120)
    p.set_defaults(func=cmd_test)
    p = sub.add_parser("gate", help="Run final release readiness checks")
    p.add_argument("--workspace", default=".")
    p.add_argument("--timeout", type=int, default=300)
    p.add_argument("--output", default=None)
    p.add_argument("--skip-tests", action="store_true", help="Skip full pytest suite; report will not pass")
    p.set_defaults(func=cmd_gate)
    p = sub.add_parser("benchmark", help="Run a local runtime smoke benchmark")
    p.add_argument("--workspace", default=".")
    p.add_argument("--iterations", type=int, default=5)
    p.add_argument("--timeout", type=int, default=15)
    p.add_argument("--output", default=None)
    p.set_defaults(func=cmd_benchmark)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    if getattr(args, "iterations", 1) < 1 or getattr(args, "iterations", 1) > 1000:
        parser.error("--iterations must be between 1 and 1000")
    if getattr(args, "command", None) == []:
        parser.error("runtime requires a command after --")
    if getattr(args, "command", None):
        args.command = args.command[1:] if args.command[0] == "--" else args.command
    try:
        return args.func(args)
    except (ValueError, OSError, RuntimeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
