# M12 — Final release gate

M12 adds a release-readiness gate that checks required project files, presence
of automated tests, Python syntax compilation, and (unless explicitly disabled)
the full pytest suite. It produces a JSON report with individual check results,
failed check names, timing, and explicit limitations.

```bash
python -m harness.cli gate --workspace .
```

A passing gate means these local checks passed. It is not a guarantee that every
generated application meets its product requirements, that cloud services work,
or that an Android APK can be built/installed. Those require project-specific
acceptance tests and the relevant SDKs, credentials, and target devices.
