from harness.agents.planner import PlannerAgent
from harness.models.spec import AppSpec, Requirement, Stack
from harness.providers.mock import MockProvider
from harness.orchestration.dag import PlanValidator

def make_spec():
    reqs = [
        Requirement(id="REQ-001", text="Authentication", acceptance="Login works"),
        Requirement(id="REQ-002", text="Projects", acceptance="Projects work"),
        Requirement(id="REQ-003", text="Tasks", acceptance="Tasks work"),
        Requirement(id="REQ-004", text="Dashboard", acceptance="Dashboard works"),
    ]
    return AppSpec(app_type="web", stack=Stack(), requirements=reqs,
                   must_have=[r.text for r in reqs],
                   explicit_non_goals=["deployment", "mobile-app", "browser-automation"],
                   acceptance_criteria=[r.acceptance for r in reqs])

def test_todo_style_plan_rules():
    tasks = PlannerAgent(MockProvider()).plan(make_spec())
    assert 5 <= len(tasks) <= 8
    assert PlanValidator().validate(tasks, ["REQ-001","REQ-002","REQ-003","REQ-004"]) == []
    for i, task in enumerate(tasks, 1):
        assert task.id == f"TASK-{i:03d}"
        assert task.files_touched
        assert task.requirements
        assert task.verification
        assert all(int(d.split("-")[1]) < i for d in task.depends_on)
