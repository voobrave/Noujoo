from harness.models.spec import AppSpec, Requirement
from harness.models.tasks import Task
from harness.models.results import VerificationResult, FailureType
from harness.verification.traceability import TraceabilityEngine
def make_spec():
    return AppSpec(app_type="web", requirements=[
        Requirement(id="REQ-001", text="Users can create tasks", must_have=True, acceptance="task creation works"),
        Requirement(id="REQ-002", text="Users can view dashboard", must_have=True, acceptance="dashboard loads")],
        must_have=["Users can create tasks", "Users can view dashboard"],
        acceptance_criteria=["task creation works", "dashboard loads"])
def result(task_id, status, command, exit_code, stdout="", stderr=""):
    return VerificationResult(task_id=task_id, status=status, command=command, exit_code=exit_code,
        stdout=stdout, stderr=stderr, duration_ms=20,
        failure_type=FailureType.TEST_FAILURE if exit_code else FailureType.UNKNOWN)
def test_full_requirement_trace_passes(tmp_path):
    tasks = [
        Task(id="TASK-001", description="tasks", files_touched=["app/tasks.py"], requirements=["REQ-001"], verification=["pytest tests/test_tasks.py -q"]),
        Task(id="TASK-002", description="dashboard", files_touched=["app/dashboard.py"], requirements=["REQ-002"], verification=["pytest tests/test_dashboard.py -q"])]
    report = TraceabilityEngine().build("run_001", make_spec(), tasks, [
        result("TASK-001", "PASS", tasks[0].verification[0], 0, "1 passed"),
        result("TASK-002", "PASS", tasks[1].verification[0], 0, "1 passed")])
    assert report.status == "PASS"
    assert [r.status for r in report.requirements] == ["PASS", "PASS"]
    assert report.requirements[0].task_ids == ["TASK-001"]
    assert report.requirements[0].files == ["app/tasks.py"]
    assert "exit_code=0" in report.requirements[0].evidence[0]
def test_missing_requirement_task_fails():
    task = Task(id="TASK-001", description="tasks", files_touched=["app/tasks.py"], requirements=["REQ-001"], verification=["pytest -q"])
    report = TraceabilityEngine().build("run_001", make_spec(), [task], [result("TASK-001", "PASS", "pytest -q", 0, "passed")])
    req = next(r for r in report.requirements if r.requirement_id == "REQ-002")
    assert report.status == "FAIL" and "no task maps to requirement" in req.missing
def test_failed_verification_has_no_pass_evidence():
    tasks = [
        Task(id="TASK-001", description="tasks", files_touched=["app/tasks.py"], requirements=["REQ-001"], verification=["pytest -q"]),
        Task(id="TASK-002", description="dashboard", files_touched=["app/dashboard.py"], requirements=["REQ-002"], verification=["pytest -q"])]
    report = TraceabilityEngine().build("run_001", make_spec(), tasks, [
        result("TASK-001", "FAIL", "pytest -q", 1, stderr="FAILED"),
        result("TASK-002", "PASS", "pytest -q", 0, "1 passed")])
    req = next(r for r in report.requirements if r.requirement_id == "REQ-001")
    assert req.status == "FAIL" and "no passing verification evidence" in req.missing
def test_trace_report_is_saved(tmp_path):
    report = TraceabilityEngine().build("run_001", make_spec(), [], [])
    out = tmp_path / "traceability.json"
    TraceabilityEngine().save(report, out)
    assert out.exists() and '"REQ-001"' in out.read_text()
