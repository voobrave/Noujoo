import pytest
from harness.models.tasks import Task, TaskStatus
from harness.orchestration.dag import DagEngine, PlanValidator

def test_cycle_fixture():
    tasks = [
        Task(id="TASK-001", description="a", depends_on=["TASK-002"],
             files_touched=["a.py"], requirements=["REQ-001"], verification=["pytest -q"]),
        Task(id="TASK-002", description="b", depends_on=["TASK-001"],
             files_touched=["b.py"], requirements=["REQ-001"], verification=["pytest -q"]),
    ]
    assert any("cycle" in e for e in PlanValidator().validate(tasks, ["REQ-001"]))
    with pytest.raises(ValueError, match="cycle"):
        DagEngine(tasks).topological_order()

def test_failure_blocks_dependents():
    tasks = [
        Task(id="TASK-001", description="a", files_touched=["a.py"],
             requirements=["REQ-001"], verification=["pytest -q"]),
        Task(id="TASK-002", description="b", depends_on=["TASK-001"],
             files_touched=["b.py"], requirements=["REQ-001"], verification=["pytest -q"]),
    ]
    engine = DagEngine(tasks)
    engine.mark("TASK-001", TaskStatus.FAILED)
    engine.blocked_propagation()
    assert engine.statuses["TASK-002"] == TaskStatus.BLOCKED

def test_sequential_execution():
    tasks = [
        Task(id="TASK-001", description="a", files_touched=["a.py"],
             requirements=["REQ-001"], verification=["pytest -q"]),
        Task(id="TASK-002", description="b", depends_on=["TASK-001"],
             files_touched=["b.py"], requirements=["REQ-001"], verification=["pytest -q"]),
    ]
    seen = []
    engine = DagEngine(tasks)
    engine_runner = __import__("harness.orchestration.dag", fromlist=["SequentialExecutor"]).SequentialExecutor(
        engine, lambda t: seen.append(t.id)
    )
    statuses = engine_runner.run()
    assert seen == ["TASK-001", "TASK-002"]
    assert all(v == TaskStatus.COMPLETED for v in statuses.values())
