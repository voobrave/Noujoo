import json
import pytest
from harness.agents.builder import BuilderAgent
from harness.models.tasks import Task
from harness.sandbox.local import LocalSandbox

class GoodProvider:
    def generate(self, prompt):
        return json.dumps({
            "main.py": "from fastapi import FastAPI\napp=FastAPI()\n",
            "requirements.txt": "fastapi>=0.100\npytest>=7.0\n"
        })

class BadProvider:
    def generate(self, prompt):
        return json.dumps({"outside.txt": "blocked"})

class InvalidProvider:
    def generate(self, prompt):
        return "not json"

def make_task(files):
    return Task(id="TASK-001", description="scaffold",
                files_touched=files, requirements=["REQ-001"],
                verification=["pytest -q"])

def test_builder_allowlist(tmp_path):
    sb = LocalSandbox(tmp_path)
    out = BuilderAgent(GoodProvider(), sb).build(make_task(["main.py","requirements.txt"]))
    assert set(out) == {"main.py","requirements.txt"}
    assert (tmp_path/"main.py").exists()

def test_bad_output_falls_back(tmp_path):
    sb = LocalSandbox(tmp_path)
    out = BuilderAgent(BadProvider(), sb).build(make_task(["main.py"]))
    assert "main.py" in out
    assert not (tmp_path.parent/"outside.txt").exists()

def test_invalid_output_falls_back(tmp_path):
    sb = LocalSandbox(tmp_path)
    out = BuilderAgent(InvalidProvider(), sb).build(
        make_task(["main.py","models.py","requirements.txt","tests/test_health.py"]))
    assert set(out) == {"main.py","models.py","requirements.txt","tests/test_health.py"}

def test_file_tools_block_unlisted(tmp_path):
    from harness.tools.files import FileTools
    tools = FileTools(LocalSandbox(tmp_path), ["main.py"])
    with pytest.raises(PermissionError):
        tools.write("secret.txt", "blocked")
