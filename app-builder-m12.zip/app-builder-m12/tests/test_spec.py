from harness.agents.spec import SpecAgent
from harness.models.spec import AppSpec, Requirement, Stack
from harness.providers.base import LLMProvider
from harness.providers.mock import MockProvider
from harness.validation.spec_validator import SpecValidator, spec_stage
from harness.state.store import RunStore

def test_valid_todo_request_passes():
    spec = SpecAgent(MockProvider())._fallback(
        "Build me a task management web app with authentication, projects, tasks, and a dashboard."
    )
    assert SpecValidator().validate(spec) == []
    assert spec.requirements
    assert spec.acceptance_criteria

def test_conflicting_non_goal_fails():
    spec = AppSpec(
        app_type="web",
        stack=Stack(),
        requirements=[
            Requirement(id="REQ-001", text="Users can login", acceptance="Login works")
        ],
        must_have=["Users can login"],
        explicit_non_goals=["login"],
        acceptance_criteria=["Login works"],
    )
    errors = SpecValidator().validate(spec)
    assert any("conflicts" in e for e in errors)

def test_missing_acceptance_fails():
    spec = AppSpec(
        app_type="web",
        stack=Stack(),
        requirements=[Requirement(id="REQ-001", text="Create tasks")],
        must_have=["Create tasks"],
        explicit_non_goals=["deployment"],
        acceptance_criteria=[],
    )
    assert any("acceptance_criteria" in e for e in SpecValidator().validate(spec))

class RetryProvider(LLMProvider):
    def __init__(self):
        self.calls = 0
    def generate(self, prompt, system=""):
        self.calls += 1
        if self.calls == 1:
            return '{"app_type":"web","stack":{"frontend":"","backend":"FastAPI","db":"SQLite"}}'
        return SpecAgent(MockProvider())._fallback("todo app").model_dump_json()
    def generate_structured(self, prompt, schema):
        return MockProvider().generate_structured(prompt, schema)
    def stream(self, prompt):
        yield "ok"

def test_retry_loop_succeeds_on_second_attempt(tmp_path):
    store = RunStore(tmp_path / "runs")
    state = store.create_run("todo app")
    spec = spec_stage(store, state.run_id, RetryProvider(), max_attempts=2)
    assert spec.requirements
    assert store.load(state.run_id).status == "SPEC_DONE"
    assert "001-spec.json" in store.load(state.run_id).checkpoints
