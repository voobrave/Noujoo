import json
import sys
from pathlib import Path
import pytest
from harness.runtime import RuntimeRunner, RuntimeError


def test_runtime_success_and_evidence(tmp_path):
    runner = RuntimeRunner(tmp_path)
    result = runner.run([sys.executable, "-c", "print('runtime-ok')"])
    assert result.status == "PASS"
    assert result.exit_code == 0
    assert "runtime-ok" in result.stdout
    evidence = list((tmp_path / ".harness/runtime").glob("*.json"))
    assert len(evidence) == 1
    assert json.loads(evidence[0].read_text())["status"] == "PASS"


def test_nonzero_exit_captured(tmp_path):
    result = RuntimeRunner(tmp_path).run([sys.executable, "-c", "import sys; print('bad', file=sys.stderr); sys.exit(4)"])
    assert result.status == "FAIL" and result.exit_code == 4
    assert "bad" in result.stderr


def test_timeout_captured(tmp_path):
    result = RuntimeRunner(tmp_path, timeout_s=1).run([sys.executable, "-c", "import time; time.sleep(3)"])
    assert result.status == "TIMED_OUT" and result.timed_out


def test_missing_executable_startup_error(tmp_path):
    result = RuntimeRunner(tmp_path).run([str(tmp_path / "missing-executable")])
    assert result.status == "STARTUP_ERROR"


def test_cwd_escape_rejected(tmp_path):
    runner = RuntimeRunner(tmp_path / "workspace")
    with pytest.raises(RuntimeError):
        runner.run([sys.executable, "-c", "print(1)"], cwd="../../")


def test_shell_metacharacters_are_not_interpreted(tmp_path):
    result = RuntimeRunner(tmp_path).run([sys.executable, "-c", "import sys; print(sys.argv[1])", "a; echo injected"])
    assert result.status == "PASS"
    assert "a; echo injected" in result.stdout


def test_invalid_command_rejected(tmp_path):
    with pytest.raises(RuntimeError):
        RuntimeRunner(tmp_path).run([])
