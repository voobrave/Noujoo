from pathlib import Path
from harness.agents.repair_agent import RepairAgent
from harness.models.tasks import Task, TaskStatus
from harness.models.results import VerificationResult, FailureType
from harness.orchestration.dag import DagEngine
from harness.orchestration.repair import RepairLoop, apply_repair_outcome, failure_signature
from harness.sandbox.local import LocalSandbox
from harness.verification.verifier import Verifier

class ScriptProvider:
    def __init__(self, content):
        self.content = content
    def generate(self, prompt, system=""):
        return self.content
    def generate_structured(self, prompt, schema):
        raise NotImplementedError
    def stream(self, prompt):
        yield self.content

def make_task(tmp_path, script="import sys; sys.exit(1)"):
    (tmp_path / "check.py").write_text(script)
    return Task(
        id="TASK-001", description="check",
        files_touched=["check.py"],
        requirements=["REQ-001"],
        verification=["python check.py"],
    )

def test_failure_signature_is_stable_and_uses_stderr_tail():
    a = VerificationResult(task_id="TASK-001", status="FAIL", command="pytest -q",
        exit_code=1, stdout="", stderr="x\n  y", duration_ms=1, failure_type=FailureType.TEST_FAILURE)
    b = a.model_copy()
    assert failure_signature(a) == failure_signature(b)
    assert len(failure_signature(a)) == 64

def test_repair_can_fix_task_and_reverify(tmp_path):
    task = make_task(tmp_path)
    sandbox = LocalSandbox(tmp_path)
    # Provider returns complete replacement content for the permitted file.
    provider = ScriptProvider('{"check.py": "print(\\\"ok\\\")\\n"}')
    loop = RepairLoop(RepairAgent(provider, sandbox), Verifier(sandbox), max_retries=3)
    outcome = loop.run(task)
    assert outcome.status == TaskStatus.COMPLETED
    assert outcome.attempts == 1
    assert task.status == TaskStatus.COMPLETED
    assert any(v.status == "PASS" for v in outcome.verifications)

def test_repair_rejects_out_of_scope_files(tmp_path):
    task = make_task(tmp_path)
    sandbox = LocalSandbox(tmp_path)
    provider = ScriptProvider('{"other.py": "bad"}')
    agent = RepairAgent(provider, sandbox)
    failed = VerificationResult(task_id=task.id, status="FAIL", command="python check.py",
        exit_code=1, stdout="", stderr="AssertionError", duration_ms=1,
        failure_type=FailureType.TEST_FAILURE)
    try:
        agent.repair(task, failed)
    except PermissionError:
        pass
    else:
        raise AssertionError("out-of-scope repair must be rejected")

def test_max_three_repairs(tmp_path):
    task = make_task(tmp_path)
    sandbox = LocalSandbox(tmp_path)
    provider = ScriptProvider("{}")
    loop = RepairLoop(RepairAgent(provider, sandbox), Verifier(sandbox), max_retries=3)
    outcome = loop.run(task)
    assert outcome.status == TaskStatus.FAILED
    assert outcome.attempts == 2
    assert outcome.reason.startswith("ESCALATE:")

def test_repeated_signature_escalates_before_max_retries(tmp_path):
    task = make_task(tmp_path)
    sandbox = LocalSandbox(tmp_path)
    provider = ScriptProvider("{}")
    loop = RepairLoop(RepairAgent(provider, sandbox), Verifier(sandbox),
                       max_retries=3, repeat_limit=3)
    outcome = loop.run(task)
    assert outcome.status == TaskStatus.FAILED
    assert outcome.attempts == 2
    assert outcome.reason.startswith("ESCALATE:")

def test_failed_task_blocks_dependents(tmp_path):
    t1 = make_task(tmp_path)
    t2 = Task(id="TASK-002", description="dependent", depends_on=["TASK-001"],
              files_touched=["b.py"], requirements=["REQ-001"], verification=["python -c \"print(1)\""])
    engine = DagEngine([t1, t2])
    engine.mark("TASK-001", TaskStatus.FAILED)
    engine.blocked_propagation()
    assert engine.statuses["TASK-002"] == TaskStatus.BLOCKED
