import json
from pathlib import Path
from harness.cli import main


def test_new_and_runs_commands(tmp_path, capsys):
    runs = tmp_path / "runs"
    assert main(["new", "make a demo app", "--runs-dir", str(runs)]) == 0
    created = json.loads(capsys.readouterr().out)
    assert created["run_id"] == "run_001"
    assert Path(created["workspace"]).is_dir()
    assert main(["runs", "--runs-dir", str(runs)]) == 0
    listed = json.loads(capsys.readouterr().out)
    assert listed[0]["run_id"] == "run_001"


def test_doctor_json(capsys):
    assert main(["doctor"]) == 0
    data = json.loads(capsys.readouterr().out)
    assert "tools" in data and "python_version" in data


def test_runtime_cli(tmp_path, capsys):
    import sys
    assert main(["runtime", "--workspace", str(tmp_path), "--", sys.executable, "-c", "print('ok')"]) == 0
    data = json.loads(capsys.readouterr().out)
    assert data["status"] == "PASS"


def test_benchmark_creates_report(tmp_path, capsys):
    output = tmp_path / "bench.json"
    assert main(["benchmark", "--workspace", str(tmp_path / "ws"), "--iterations", "2", "--output", str(output)]) == 0
    data = json.loads(capsys.readouterr().out)
    assert data["passed"] == 2 and data["failed"] == 0
    assert json.loads(output.read_text())["iterations"] == 2
