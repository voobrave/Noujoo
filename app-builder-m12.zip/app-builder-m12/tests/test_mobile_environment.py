from harness.mobile.environment import mobile_environment_report

def test_environment_report_shape():
    report = mobile_environment_report()
    assert report["platform"] == "android/termux-or-linux-userspace"
    assert "tools" in report
    assert "flutter" in report["tools"]
    assert "apk_build_ready" in report
