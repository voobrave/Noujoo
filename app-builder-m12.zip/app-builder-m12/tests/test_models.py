from pathlib import Path
import pytest
from harness.models.spec import AppSpec, Requirement
from harness.models.tasks import Task, TaskStatus
from harness.sandbox.local import LocalSandbox
from harness.state.store import RunStore

def test_models_roundtrip():
    spec = AppSpec(
        app_type="web",
        requirements=[Requirement(id="REQ-001", text="Create tasks", acceptance="Can create")]
    )
    assert AppSpec.model_validate_json(spec.model_dump_json()).requirements[0].id == "REQ-001"

    task = Task(id="TASK-001", description="Schema", files_touched=["models.py"],
                requirements=["REQ-001"], verification=["pytest -q"])
    assert Task.model_validate_json(task.model_dump_json()).status == TaskStatus.PENDING

def test_sandbox_jail(tmp_path):
    sandbox = LocalSandbox(tmp_path / "workspace")
    sandbox.write_file("ok.txt", "ok")
    with pytest.raises(PermissionError):
        sandbox.write_file("../escape.txt", "nope")

def test_store_save_load(tmp_path):
    store = RunStore(tmp_path / "runs")
    state = store.create_run("build a todo app")
    loaded = store.load(state.run_id)
    assert loaded.run_id == state.run_id
    assert loaded.user_request == "build a todo app"
