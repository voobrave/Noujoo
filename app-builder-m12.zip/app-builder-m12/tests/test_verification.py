import sys
import time
from harness.models.tasks import Task
from harness.models.results import FailureType
from harness.sandbox.local import LocalSandbox
from harness.verification.verifier import Verifier
from harness.verification.classifier import classify_failure

def make_task(command):
    return Task(id="TASK-TEST", description="verify", files_touched=[],
                requirements=["REQ-001"], verification=[command])

def test_verifier_passes(tmp_path):
    sb=LocalSandbox(tmp_path)
    v=Verifier(sb)
    r=v.verify("TASK-001", f"{sys.executable} -c \"print('ok')\"")
    assert r.status=="PASS"
    assert r.exit_code==0
    assert r.stdout=="ok\n"

def test_output_is_capped(tmp_path):
    sb=LocalSandbox(tmp_path)
    v=Verifier(sb)
    cmd=f"{sys.executable} -c \"print('x'*10000)\""
    r=v.verify("TASK-001", cmd)
    assert r.status=="PASS"
    assert len(r.stdout)<=4000

def test_syntax_error_classification():
    assert classify_failure(1,"","SyntaxError: invalid syntax")==FailureType.CODE_ERROR

def test_import_error_classification():
    assert classify_failure(1,"","ModuleNotFoundError: no module")==FailureType.DEPENDENCY_ERROR

def test_test_failure_classification():
    assert classify_failure(1,"","pytest\nFAILED test_x")==FailureType.TEST_FAILURE

def test_type_failure_classification():
    assert classify_failure(1,"","TypeError: bad value")==FailureType.TYPE_ERROR

def test_config_failure_classification():
    assert classify_failure(1,"","missing configuration key")==FailureType.CONFIG_ERROR

def test_environment_failure_classification():
    assert classify_failure(1,"","EAI_AGAIN registry.example")==FailureType.ENVIRONMENT_ERROR

def test_timeout_classification():
    assert classify_failure(-1,"","TimeoutExpired",timed_out=True)==FailureType.TIMEOUT

def test_verify_task_runs_commands(tmp_path):
    sb=LocalSandbox(tmp_path)
    (tmp_path/"requirements.txt").write_text("# no deps\n")
    v=Verifier(sb)
    task=make_task(f"{sys.executable} -c \"print('verified')\"")
    results=v.verify_task(task)
    # Installation of an empty requirements file is valid.
    assert results[-1].status=="PASS"
    assert results[-1].stdout=="verified\n"
