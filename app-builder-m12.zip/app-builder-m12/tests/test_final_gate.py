from pathlib import Path
from harness.release import run_final_gate, write_gate_report


def test_final_gate_checks_structure_and_compile_without_tests():
    root = Path(__file__).resolve().parents[1]
    report = run_final_gate(root, run_tests=False)
    assert report["status"] == "FAIL"  # Explicitly skipped tests cannot be a release pass.
    assert "required_release_files" in [check["name"] for check in report["checks"]]
    assert next(check for check in report["checks"] if check["name"] == "python_compile")["passed"]


def test_final_gate_report_written_atomically(tmp_path):
    path = write_gate_report({"status": "PASS"}, tmp_path / "nested" / "gate.json")
    assert path.is_file()
    assert '"status": "PASS"' in path.read_text()
    assert not path.with_suffix(".json.tmp").exists()
