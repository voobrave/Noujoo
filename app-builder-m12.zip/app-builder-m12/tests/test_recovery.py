import json

import pytest

from harness.models.run import RunState, RunStatus
from harness.models.tasks import Task, TaskStatus
from harness.recovery import RecoveryError, RecoveryManager
from harness.state.store import RunStore


def make_state(store):
    state = store.create_run("Build a small todo app")
    state.status = RunStatus.BUILDING
    state.plan = [
        Task(id="TASK-001", description="Create schema", status=TaskStatus.COMPLETED,
             files_touched=["src/models.py"], requirements=["REQ-001"], verification=["pytest -q"]),
        Task(id="TASK-002", description="Create API", depends_on=["TASK-001"],
             status=TaskStatus.RUNNING, files_touched=["src/main.py"],
             requirements=["REQ-001"], verification=["pytest -q"]),
        Task(id="TASK-003", description="Add tests", depends_on=["TASK-002"],
             status=TaskStatus.READY, files_touched=["tests/test_app.py"],
             requirements=["REQ-001"], verification=["pytest -q"]),
    ]
    store.checkpoint(state, "002-plan.json", {"tasks": [t.model_dump(mode="json") for t in state.plan]})
    return state


def test_recovery_preserves_completed_tasks_and_resets_interrupted_tasks(tmp_path):
    store = RunStore(tmp_path / "runs")
    state = make_state(store)
    outcome = RecoveryManager(store).recover(state.run_id)

    assert outcome.recovered is False
    assert outcome.completed_task_ids == ["TASK-001"]
    assert outcome.resumable_task_ids == ["TASK-002", "TASK-003"]
    statuses = {task.id: task.status for task in outcome.state.plan}
    assert statuses["TASK-001"] == TaskStatus.COMPLETED
    assert statuses["TASK-002"] == TaskStatus.PENDING
    assert statuses["TASK-003"] == TaskStatus.PENDING
    assert (tmp_path / "runs" / state.run_id / "checkpoints" / "006-recovery.json").exists()


def test_recovery_restores_corrupt_state_from_latest_snapshot(tmp_path):
    store = RunStore(tmp_path / "runs")
    state = make_state(store)
    state_path = tmp_path / "runs" / state.run_id / "state.json"
    state_path.write_text("{broken json", encoding="utf-8")

    outcome = RecoveryManager(store).recover(state.run_id)
    assert outcome.recovered is True
    assert "state-002-plan.json" in outcome.source
    assert RunState.model_validate_json(state_path.read_text(encoding="utf-8")).run_id == state.run_id
    assert any("invalid" in warning for warning in outcome.warnings)


def test_recovery_fails_safely_when_state_and_snapshots_are_corrupt(tmp_path):
    store = RunStore(tmp_path / "runs")
    state = store.create_run("Keep data safe")
    run_dir = tmp_path / "runs" / state.run_id
    (run_dir / "state.json").write_text("bad", encoding="utf-8")
    with pytest.raises(RecoveryError, match="No files were changed"):
        RecoveryManager(store).recover(state.run_id)
    assert (run_dir / "state.json").read_text(encoding="utf-8") == "bad"


def test_recovery_rejects_path_traversal_run_id(tmp_path):
    store = RunStore(tmp_path / "runs")
    with pytest.raises(RecoveryError, match="Invalid run ID"):
        RecoveryManager(store).recover("run_../outside")


def test_checkpoint_snapshots_are_validated_and_atomic_state_saved(tmp_path):
    store = RunStore(tmp_path / "runs")
    state = store.create_run("Snapshot test")
    checkpoint = store.checkpoint(state, "001-spec.json", {"spec": {"app_type": "web"}})
    assert json.loads(checkpoint.read_text(encoding="utf-8"))["spec"]["app_type"] == "web"
    snapshot = checkpoint.parent / "state-001-spec.json"
    assert RunState.model_validate_json(snapshot.read_text(encoding="utf-8")).run_id == state.run_id
    assert not (checkpoint.parent.parent / "state.json.tmp").exists()
