import json
from harness.agents.reviewer import RequirementReviewer
from harness.models.spec import AppSpec, Requirement
from harness.models.traceability import RequirementTrace, TraceabilityReport
from harness.orchestration.review import requirement_review_stage
from harness.models.run import RunState


def sample_spec():
    return AppSpec(app_type="web", requirements=[
        Requirement(id="REQ-001", text="Users can create tasks", acceptance="Task creation succeeds"),
        Requirement(id="REQ-002", text="Users can search tasks", acceptance="Search returns matches"),
    ])


def test_review_passes_with_traceable_evidence_and_existing_files(tmp_path):
    (tmp_path / "tasks.py").write_text("def create_task(): return True\n")
    (tmp_path / "search.py").write_text("def search_tasks(): return []\n")
    trace = TraceabilityReport(run_id="run_001", status="PASS", requirements=[
        RequirementTrace(requirement_id="REQ-001", task_ids=["TASK-001"], files=["tasks.py"],
            commands=["pytest -q"], evidence=["TASK-001: command='pytest -q'; exit_code=0; stdout='1 passed'; stderr='"], status="PASS"),
        RequirementTrace(requirement_id="REQ-002", task_ids=["TASK-002"], files=["search.py"],
            commands=["pytest -q"], evidence=["TASK-002: command='pytest -q'; exit_code=0; stdout='1 passed'; stderr='"], status="PASS"),
    ])
    report = RequirementReviewer().review("run_001", sample_spec(), trace, tmp_path)
    assert report.status == "PASS"
    assert report.total_requirements == 2 and report.passed_requirements == 2


def test_review_fails_when_mapped_file_missing(tmp_path):
    trace = TraceabilityReport(run_id="run_001", status="PASS", requirements=[
        RequirementTrace(requirement_id="REQ-001", task_ids=["TASK-001"], files=["missing.py"],
            commands=["pytest -q"], evidence=["exit_code=0"], status="PASS"),
        RequirementTrace(requirement_id="REQ-002", task_ids=["TASK-002"], files=["missing2.py"],
            commands=["pytest -q"], evidence=["exit_code=0"], status="PASS"),
    ])
    report = RequirementReviewer().review("run_001", sample_spec(), trace, tmp_path)
    assert report.status == "FAIL"
    assert any("does not exist" in reason for reason in report.requirements[0].missing)


def test_review_rejects_unsafe_paths(tmp_path):
    trace = TraceabilityReport(run_id="run_001", status="PASS", requirements=[
        RequirementTrace(requirement_id="REQ-001", task_ids=["TASK-001"], files=["../outside.py"],
            commands=["pytest -q"], evidence=["exit_code=0"], status="PASS"),
        RequirementTrace(requirement_id="REQ-002", task_ids=["TASK-002"], files=["search.py"],
            commands=["pytest -q"], evidence=["exit_code=0"], status="PASS"),
    ])
    report = RequirementReviewer().review("run_001", sample_spec(), trace, tmp_path)
    assert report.requirements[0].status == "FAIL"
    assert any("unsafe file path" in reason for reason in report.requirements[0].missing)


def test_review_stage_writes_artifact_and_checkpoint(tmp_path):
    (tmp_path / "tasks.py").write_text("# generated\n")
    (tmp_path / "search.py").write_text("# generated\n")
    state = RunState(run_id="run_001", trace_id="trace_1", user_request="todo", workspace=str(tmp_path), spec=sample_spec())
    trace = TraceabilityReport(run_id="run_001", status="PASS", requirements=[
        RequirementTrace(requirement_id="REQ-001", task_ids=["TASK-001"], files=["tasks.py"], commands=["pytest -q"], evidence=["exit_code=0"], status="PASS"),
        RequirementTrace(requirement_id="REQ-002", task_ids=["TASK-002"], files=["search.py"], commands=["pytest -q"], evidence=["exit_code=0"], status="PASS"),
    ])
    report = requirement_review_stage(state, trace, store=None)
    assert (tmp_path / "review.json").is_file()
    assert state.status == "REVIEW_DONE"
    assert "005-review.json" in state.checkpoints
    parsed = json.loads((tmp_path / "review.json").read_text())
    assert parsed["status"] == "PASS"
