# App-Builder Harness — Mobile Edition

A lightweight autonomous coding harness designed to run on Android through Termux and an Ubuntu userspace.

## Architecture

Android -> Termux -> Ubuntu/Linux userspace -> Python 3.11+ -> App-Builder Harness

The core harness stays Python/stdlib-first. Android/Flutter APK building is an optional later layer.

## Mobile setup

1. Install Termux from a trusted current source.
2. Inside Termux, create/use an Ubuntu userspace.
3. Install Python 3.11+, pip, git and basic build tools inside Ubuntu.
4. Extract this project.
5. Run:
   `python -m pip install -e .`
6. Test:
   `python -m pytest -q`

## CLI

M1 provides infrastructure. Later milestones add:
`python -m harness.cli new "Build me a todo app"`

## APK layer

Do not assume Android SDK/Flutter is installed. The mobile edition provides a compatibility check so the harness can report what is available instead of pretending an APK was built.


## M6 — Repair and Loop Detection

M6 adds a bounded repair/reverification loop. Repairs may only write files declared by the failed task. Each failed verification gets a SHA-256 signature from command, exit code, and normalized stderr tail; repeated signatures trigger `ESCALATE`, while repairs are capped at 3. Failed tasks propagate `BLOCKED` status to dependents.


## M7 — Requirement Traceability

M7 produces `traceability.json`, linking each REQ-ID to TASK-IDs, touched files,
verification commands, and passing evidence. A requirement passes only when it
has a mapped task, files, a verification command, and evidence with exit code 0.
Missing links are listed explicitly and cause the report to fail.


## M8 — Evidence-based Requirement Review

M8 writes `review.json` after traceability. Each requirement is checked for a traceability record, linked tasks, verification commands, passing evidence (`exit_code=0`), acceptance text, and mapped files that actually exist inside the workspace. Absolute and parent-traversal paths are rejected. The run is marked `REVIEW_DONE` only when every requirement passes; otherwise it is marked `FAIL`. When a `RunStore` is provided, the stage also writes `checkpoints/005-review.json`. This review validates evidence and file presence; it does not replace functional acceptance tests.

## M9 — Crash recovery

`RecoveryManager` loads a run from `state.json`, or restores the most recent valid
state snapshot if the state file is corrupted. Checkpoints are retained; recovery
never deletes user files or checkpoints. Tasks marked `RUNNING` at interruption
are reset to `PENDING`, while `COMPLETED` tasks remain completed to avoid repeating
finished work. Recovery writes `006-recovery.json` and appends a JSONL event.

Run the recovery tests with:

```bash
python -m pytest -q
```

## M10 — Runtime execution

M10 adds a bounded runtime runner that executes argument arrays without a shell,
rejects working directories outside the project workspace, captures startup
errors/timeouts/output, and writes JSON evidence under `.harness/runtime/`.
This is not a full OS-level sandbox; run untrusted code in a disposable environment.
See `M10_RUNTIME.md`.

## M11 — CLI and benchmarks

Run `python -m harness.cli --help` for local commands covering environment
checks, run creation/listing, recovery, workspace runtime execution, Python
compile/tests, and a small JSON-emitting runtime benchmark. See `M11_CLI_BENCHMARKS.md`.

## M12 — Final release gate

Run `python -m harness.cli gate --workspace .` for required-file checks, syntax
compilation, and the full test suite. A JSON report is saved to
`.harness/final-gate.json`. A pass applies only to these checks and is not a
claim of production deployment or universal app correctness. See `M12_FINAL_GATE.md`.
