# M9 — Recovery milestone

This is the M9 project package based on the supplied M8 checkpoint. It is a separate
successor ZIP; it was not merged with the other milestone ZIP archives.

## Included
- Atomic `state.json` writes.
- Atomic checkpoint writes.
- Full state snapshot beside each checkpoint.
- Recovery from the latest valid snapshot when `state.json` is invalid.
- Conservative task reconciliation: completed tasks stay completed; interrupted
  `RUNNING` tasks return to `PENDING`; `READY` tasks return to `PENDING`.
- Recovery event in `events.log` and `006-recovery.json` checkpoint.
- Safe failure without modifying files if no valid state snapshot exists.

## Verify
From this directory, run:

```bash
python -m pip install -e .
python -m pytest -q
```

The test suite passed in the build environment: 45 passed.
