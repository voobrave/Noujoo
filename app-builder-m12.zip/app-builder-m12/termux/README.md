# Termux setup

This directory contains mobile setup guidance.

## Suggested flow

```bash
pkg update
pkg upgrade
pkg install git proot-distro
proot-distro install ubuntu
proot-distro login ubuntu
```

Inside Ubuntu, install a supported Python 3.11+ environment and development tools.

Then enter the project directory and run:

```bash
python -m pip install -e .
python -m pytest -q
python -m harness.mobile.cli
```

For APK generation, install a compatible Flutter/Android SDK toolchain separately. The harness should detect whether it is available before attempting an APK build.
