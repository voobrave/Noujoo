#!/usr/bin/env bash
set -e
echo "App-Builder mobile bootstrap"
echo "Run this inside Termux:"
echo "  pkg update"
echo "  pkg install git proot-distro"
echo "  proot-distro install ubuntu"
echo "  proot-distro login ubuntu"
echo
echo "Then install Python 3.11+, pip and git inside Ubuntu."
echo "Finally:"
echo "  python -m pip install -e ."
echo "  python -m pytest -q"
echo "  python -m harness.mobile.cli"
