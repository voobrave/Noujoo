# M10 — Runtime execution and evidence

M10 adds `RuntimeRunner` for launching project commands without a shell, bounded
execution time, workspace-contained working directories, a minimal environment,
bounded stdout/stderr capture, explicit `PASS` / `FAIL` / `TIMED_OUT` /
`STARTUP_ERROR` outcomes, and atomically saved JSON evidence under
`.harness/runtime/`.

Example:

```python
from harness.runtime import RuntimeRunner
runner = RuntimeRunner("./generated-project", timeout_s=60)
result = runner.run(["python", "-m", "pytest", "-q"], label="acceptance-tests")
print(result.status, result.exit_code)
```

This path validation is not a full OS sandbox. Run untrusted generated code only
in a disposable environment without secrets. `check_python_project()` performs
compileall followed by pytest, stopping if compilation fails.
